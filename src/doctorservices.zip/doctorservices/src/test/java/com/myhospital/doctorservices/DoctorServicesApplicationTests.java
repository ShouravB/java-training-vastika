package com.myhospital.doctorservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
