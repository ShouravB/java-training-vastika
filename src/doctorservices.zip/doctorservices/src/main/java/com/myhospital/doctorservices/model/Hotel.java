package com.myhospital.doctorservices.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor @AllArgsConstructor@Setter
public class Hotel {

    @Getter
    private String name;
    @Getter
    @JsonProperty(value = "no_of_guests")
    private int noOfGuests;
    @Getter
    private Address address;
    @Getter
    private List<Guest> guests;
    @Getter
    @JsonProperty(value="is_open")
    private boolean isOpen;

    @Getter
    @JsonProperty(value = "opening_hour")
   private OpeningHours openingHours;
}
